package com.example.qrandbarcodegenerator;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class generator extends AppCompatActivity {
    EditText editText;
    Button button;
    ImageView imageView,imageview2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generator);
        editText = (EditText)findViewById(R.id.edittext);
        button = (Button)findViewById(R.id.button);
        imageView = (ImageView)findViewById(R.id.imageview);
        imageview2=findViewById(R.id.imageview2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MultiFormatWriter multiFormatWriter = new MultiFormatWriter();

                try{
                    BitMatrix bitMatrix = multiFormatWriter.encode(editText.getText().toString(), BarcodeFormat.QR_CODE,500,500);
                    BarcodeEncoder barcodeEncoder;
                    barcodeEncoder = new BarcodeEncoder();
                    Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
                    imageView.setImageBitmap(bitmap);
                    BitMatrix bitMatrix1 = multiFormatWriter.encode(editText.getText().toString(), BarcodeFormat.CODE_128,600,350);
                    BarcodeEncoder barcodeEncoder1;
                    barcodeEncoder1 = new BarcodeEncoder();
                    Bitmap bitmap1 = barcodeEncoder1.createBitmap(bitMatrix1);
                    imageview2.setImageBitmap(bitmap1);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
    }

}