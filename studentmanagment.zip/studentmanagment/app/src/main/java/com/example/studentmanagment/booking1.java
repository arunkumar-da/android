package com.example.studentmanagment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.time.Year;

public class booking1 extends AppCompatActivity {
EditText studentname,department,year;
Button button,button1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking1);
        studentname=findViewById(R.id.studentname);
        department=findViewById(R.id.department);
        year=findViewById(R.id.year);
        button1=findViewById(R.id.button1);
        button=findViewById(R.id.button);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), d.class);
                startActivity(i);
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = studentname.getText().toString()+"";
                String depart= department.getText().toString()+"";
                String yea= year.getText().toString()+"";
                RequestQueue queue = Volley.newRequestQueue(booking1.this);

                String url = "http://192.168.1.8/student/student.php?studentname="+name+"&department="+depart+"&years="+yea;


                Toast.makeText(getApplicationContext(), url, Toast.LENGTH_LONG).show();

                StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Toast.makeText(booking1.this,
                                response, Toast.LENGTH_LONG).show();

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.wtf(error.getMessage(), "utf-8");
                    }
                });

                queue.add(stringRequest);
            }

        });

    }
}