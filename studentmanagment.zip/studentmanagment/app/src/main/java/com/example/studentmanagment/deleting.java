package com.example.studentmanagment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class deleting extends AppCompatActivity {
EditText studentname1;
Button button2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deleting);
        studentname1.findViewById(R.id.studentname);
        button2=findViewById(R.id.button);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = studentname1.getText().toString()+"";
                RequestQueue queue = Volley.newRequestQueue(deleting.this);

                String url = "http://192.168.1.8/student/z.php?studentname="+name;
//                String url = "http://192.168.172.91/c/c/c.php?firstname=arunkumar&lastname=arunkumar&email=arun@gmail.com";




                StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Toast.makeText(deleting.this,
                                response, Toast.LENGTH_LONG).show();

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.wtf(error.getMessage(), "utf-8");
                    }
                });

                queue.add(stringRequest);
            }

        });
    }
}